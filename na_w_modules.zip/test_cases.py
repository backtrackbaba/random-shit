import time
import unittest

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys


class FirstUnitTest(unittest.TestCase):
    driver = None

    @classmethod
    def setUp(self):
        options = Options()
        # options.add_argument('--headless')
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        self.driver = webdriver.Chrome('/Users/sai/bin/ga/chromedriver', options=options)
        # self.driver = webdriver.remote(command_executor='http://localhost:4444/wd/hub',desired_capabilities=webdriver.DesiredCapabilities.HTMLUNIT)
        # self.driver = webdriver.Remote(command_executor='http://127.0.0.1:4444/wd/hub', desired_capabilities=DesiredCapabilities.HTMLUNITWITHJS)
        # print("herer")
        # self.driver.get('https://www.google.com')
        self.driver.implicitly_wait(10)
        self.driver.maximize_window()
        time.sleep(5)

    def test_valid_search(self):
        self.driver.get('http://localhost:8080/')
        self.driver.current_url
        search = self.driver.find_element_by_id('search')
        search.send_keys('mahesh')
        search.send_keys(Keys.RETURN)
        time.sleep(5)
        result = self.driver.find_element_by_css_selector('#news-articles > li')
        assert result.get_attribute('class') == 'article'
        time.sleep(5)

    def test_invalid_search(self):
        self.driver.get('http://localhost:8080/')
        search = self.driver.find_element_by_id('search').get_attribute()
        search.send_keys('alkjsdklads')
        search.send_keys(Keys.RETURN)
        time.sleep(5)
        result = self.driver.find_element_by_css_selector('#news-articles > li')
        assert result.get_attribute('class') == 'not-found'
        time.sleep(5)

    def test_hover_mahe(self):
        self.driver.get('http://localhost:8080/')
        time.sleep(3)
        result = self.driver.find_element_by_css_selector('#news-articles > li:nth-child(1)').value_of_css_property(
            'font-family')
        print(result)
        result = self.driver.find_element_by_css_selector(
            '#news-articlesasdasdasd > li:nth-child(1)').value_of_css_property(':hover')
        print(result)
        time.sleep(5)

    def test_hover(self):
        self.driver.get('http://localhost:8080/')
        time.sleep(3)
        element = self.driver.find_element_by_css_selector('#news-articles > li:nth-child(1)')
        transform_before = element.value_of_css_property('transform')
        ActionChains(self.driver).move_to_element(element).perform()
        transform_after = element.value_of_css_property('transform')
        assert transform_after == transform_before

    @classmethod
    def tearDown(self):
        self.driver.quit()


if __name__ == '__main__':
    unittest.main(verbosity=2)
